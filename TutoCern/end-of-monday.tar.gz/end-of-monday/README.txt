`end-of-monday.tar.gz` contains the state of our code at the end of Monday.
Download it on your virtual machine (will be downloaded into the `Downloads`
directory), copy to you local work directory and extract there with the 

 tar -xzvf end-of-monday.tar.gz

This will be our starting point on Tuesday.
